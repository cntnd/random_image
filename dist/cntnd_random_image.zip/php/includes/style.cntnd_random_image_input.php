<style>
<?= file_get_contents($cfgClient[$client]["module"]["path"].'cntnd_random_image/css/cntnd_random_image.css') ?>
</style>
